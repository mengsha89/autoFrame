

|--dt_auto_frame
    |--common   公共方法
        |--HTMLTestRunner.py
        |--send_email.py
        |--log  日志
    |--cases    测试用例集
        |--test
    |--logs     日志文件
    |--config   配置文件
    |--data     测试数据
    |--reports  测试报告
    |--public_class 
    |--methods  接口方法
    |--test_suites  批量运行测试用例
    |--readme.md
# coding=utf-8
# author:ss


from selenium import webdriver

driver = webdriver.Chrome()
driver.get("https://www.aixuexi.com/")